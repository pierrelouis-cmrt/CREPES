# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import numpy as np
import matplotlib.pyplot as plt

alpha = 23.53*np.pi/180

x = np.linspace(-np.pi, np.pi, 1000)
xg= (np.pi/180)* np.asarray([90.25,84.71,63.29,47.9,30.35,21.16,8.53,4.03])
geo= (np.pi/180)*np.asarray([23.53,23.44,21.25,17.9,12.41,8.93,3.69,1.75])


f = alpha*np.sin(x) #version élèves
#y = (np.arccos((np.cos(x))**2 +(np.sin(x))**2 * (np.cos(alpha))))*np.sign(np.sin(x)) #version produit scalaire, mais pas si clair le vecteur tournant sur le 1er cercle
z= np.arccos(np.cos(alpha)/np.sqrt(np.cos(alpha)**2 + np.sin(alpha)**2*np.cos(x-np.pi/2)**2))*np.sign(np.cos(x-np.pi/2)) #version tablette, géométrie douteuse (renormalisation incertaine)
#z2 = np.arcsin(np.sin(x)*np.sin(alpha))
#z2 = np.arccos(np.sqrt((np.sin(x)*np.cos(alpha))**2 + np.cos(x)**2))*np.sign(np.sin(x))

fig,ax = plt.subplots()

#pour la régression :



#pour les points pris en préparation
#plt.errorbar(x,y,xerr=ux,yerr=uy,marker='+', color = 'red', linestyle= '',label = 'Points simulés')
#pour le point pris en direct
#plt.errorbar(x,y,xerr=uxdir,yerr=uydir,marker='+', color = 'green', linestyle= '',label='ln(%)')

#on légende titre les axes
ax.set_ylabel("Longitude (rad)",fontsize=25)
ax.set_xlabel("Latitude du zénith parfait (rad)",fontsize=30)
ax.tick_params(axis='both', which='major', labelsize=30)
ax.tick_params(axis='both', which='minor', labelsize=30)
#plt.yticks(fontsize=40)
#ax.set_ylim([-0.5, 6.5])
#ax.set_xlim([0, t[-1]])



# Show the major grid and style it slightly.
ax.grid(which='major', color='#DDDDDD', linewidth=3)
# Show the minor grid as well. Style it in very light gray as a thin,
# dotted line.
ax.grid(which='minor', color='#EEEEEE', linestyle=':', linewidth=1.5)
# Make the minor ticks and gridlines show.
ax.minorticks_on()
#ax.legend(fontsize=40)

ax.plot(x,f, color = 'black', linestyle= 'solid',linewidth = 1,label = "solution élève")

ax.plot(x,z, color = 'green', linestyle= 'solid',linewidth = 1,label = "solution Brian")


ax.plot(x,f-z, color = 'red', linestyle= 'solid',linewidth = 1,label ="résidu")
ax.scatter(xg,geo, color = 'red',label = "solution géogébra")
ax.legend(loc='best',fontsize=20)
plt.show()

print(np.round(100*np.max(f-z)/0.4,2), "%,  l'erreur relative maximale")