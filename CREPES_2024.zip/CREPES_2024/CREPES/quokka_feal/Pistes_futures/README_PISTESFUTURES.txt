# [Readme Pistes_futures]

## Contenu

[un fichier dans le modèle 1 :
- [Inertie_terre.docx](https://github.com/quokkafeal6/IPCC/blob/main/Pistes_futures/Inertie_terre.docx) c'est le fichier word explicant comment améliorer la formule des corps noir afin d'avoir une température non nulle la nuit.
- [Inertie_terre.docx](https://github.com/quokkafeal6/IPCC/blob/main/Pistes_futures/Variations saisonnières) c'est le fichier pdf avec des pistes de reflexion sur les variations saisonnières et des résultats partiels. ]
