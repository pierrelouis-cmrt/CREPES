import numpy as np
import matplotlib.pyplot as plt
import math

# Paramètres
r = 6371  # Rayon de la Terre
n = 10  # Nombre de segments de la Terre
R = r + 10000   # Rayon de l'atmosphère
N = 10 # Nombre de points de l'atmosphère
h = R - r #epaisseur atmosphere
D = 25000 #distance entre centre de la terre et Soleil
k = 50  # Nombre de rayons partant du soleil
ni =1                                       # Indice optique du vide
ind_opt = [ni, 1.001032, 1.00029214, 1.0002957, 1.0002957, 1.0002957]# Indice optique du vide et des differentes couches de l'atmosphère
h_atm = [9400, 515, 35, 35, 15]           # Epaisseur des différentes couches de l'atmosphère



#Fonctions

def Terre(N, R):
    """
    défini la terre comme un arc de cercle de rayon R centré en 0 et composé de N segments
    """
    angles = np.linspace(-np.pi / 2, np.pi / 2, N + 1)
    x = R * np.cos(angles)
    y = R * np.sin(angles)
    return x, y

def Atmosphere(N, R):
    """
    défini l'atmosphère comme un arc de cercle de rayon R centré en 0 et composé de N segments
    """
    angles = np.linspace(-np.pi / 2, np.pi / 2, N)
    x = R * np.cos(angles)
    y = R * np.sin(angles)
    return x, y

def Soleil_plan(R,D): 
    """
    défini le soleil avec une droite selon l'axe des y de hauteur 2R et centrée en 0
    """
    x_line = [D, D]
    y_line = [-R, R]
    return x_line, y_line

def Rayons_soleil(k, x_sun, y_sun_start, y_sun_end, atmosphere_radius):
    """
    défini les k rayons parallèles partant du soleil et calcule le point d'intersection de chaque rayon avec l'atmosphère
    cette fonction renvoie les coordonnées x de depart et d'arrivée du rayon ainsi que les coordonnées y de départ et d'arrivée
    """
    y_positions = np.linspace(y_sun_start, y_sun_end, k)
    x_rays = []
    y_rays = []
    for y in y_positions:
        intersection_x = np.sqrt(atmosphere_radius**2 - y**2)
        x_rays.append([x_sun, intersection_x])
        y_rays.append([y, y])
    return x_rays, y_rays

def Angle_incidence(rayon_x, rayon_y):
    """
    calcule l'angle d'incidence de chaque rayon arrivant sur l'atmosphère et renvoie l'angle d'incidence
    """
    ray_vector = np.array([rayon_x[1] - rayon_x[0], rayon_y[1] - rayon_y[0]])
    intersection_vector = np.array([rayon_x[1], rayon_y[1]])
    incidence_angle = np.arctan2(ray_vector[1], ray_vector[0]) - np.arctan2(intersection_vector[1], intersection_vector[0])
    if incidence_angle > np.pi:
        incidence_angle -= np.pi
    elif incidence_angle <= np.pi:
        incidence_angle -= np.pi
    return incidence_angle


def Angle_refracte(teta_i):
    """
    A partie de l'angle d'incidence teta_i du rayon sur l'atmosphère
    calcule l'angle teta refracté total après le passage des rayons par les 5 couches de l'atmosphère considerée comme 5 couches d'indice optique différent
    voir explication du calcul et le schéma explication dans la documentation 
    """
    teta = [teta_i]
    for i in range(1,6):
        if np.abs(np.sin(teta[i-1])*ind_opt[i-1]/ind_opt[i]) > 1:
            tetai = np.pi/2
            teta.append(tetai)
        else :
            tetai = np.arcsin(np.sin(teta[i-1])*ind_opt[i-1]/ind_opt[i])
            teta.append(tetai)
    l = []
    for i in range(0,5):
        li = np.tan(teta[i])*h_atm[i]
        l.append(li)
    ltot = 0
    htot = 0
    for i in range(0, 5):
        ltot = ltot + l[i]
        htot = htot + h_atm[i]
    tetatot = np.arctan(ltot/htot)
    return tetatot


def Rayon_refracte(x1, y1, x2, y2, x, y, theta):
    """
    a partir des coordonées des rayons partant de l'atmosphère et et arrivant sur l'atmosphère
    a l'aide d'une matrice de rotation, on incline ces rayons de l'angle teta refracté et on les prolongent
    on renvoie les nouvelles coordonnées des rayons lorsqu'ils sont dans l'atmosphère 
    """
    rotation_matrix = np.array([[np.cos(theta), -np.sin(theta)],
                                 [np.sin(theta), np.cos(theta)]])
    
    x1_rotated, y1_rotated = x1 - x, y1 - y
    x2_rotated, y2_rotated = x2 - x, y2 - y
    
    new_x1, new_y1 = np.dot(rotation_matrix, np.array([x1_rotated, y1_rotated]))
    new_x2, new_y2 = np.dot(rotation_matrix, np.array([x2_rotated, y2_rotated]))
    
    new_x1, new_y1 = new_x1 + x, new_y1 + y
    new_x2, new_y2 = new_x2 + x, new_y2 + y
    
    return new_x1, new_y1, new_x2, new_y2


def intersection_terre_rayon(r, x1, y1, x2, y2):
    """
    on souhaite que les rayons refractés calculés avec la matrice de rotation de la fonction précédente s'arretent sur la terre
    cette algorithme permet donc de calculer le point d'intersaction entre un demi cercle et une droite
    """
    # Equation du cercle : x^2 + y^2 = r^2
    # Equation du segment : (y2 - y1) * (x - x1) = (x2 - x1) * (y - y1)
    
    # Calcul de la direction du segment
    dx = x2 - x1
    dy = y2 - y1
    
    # Paramètres de l'équation quadratique Ax^2 + Bx + C = 0
    A = dx**2 + dy**2
    B = 2 * (x1 * dx + y1 * dy)
    C = x1**2 + y1**2 - r**2
    
    # Calcul du discriminant
    discriminant = B**2 - 4 * A * C
    
    if discriminant < 0:
        return []  # Pas d'intersection
    elif discriminant == 0:
        # Une seule solution (tangente)
        t = -B / (2 * A)
        xi = x1 + t * dx
        yi = y1 + t * dy
        if 0 <= t <= 1:
            return [(xi, yi)]
        else:
            return []  # Intersection hors du segment
    else:
        # Deux solutions (le segment coupe le cercle en deux points)
        sqrt_discriminant = math.sqrt(discriminant)
        t1 = (-B + sqrt_discriminant) / (2 * A)
        t2 = (-B - sqrt_discriminant) / (2 * A)
        
        intersections = []
        if 0 <= t1 <= 1:
            xi1 = x1 + t1 * dx
            yi1 = y1 + t1 * dy
            if xi1 >= 0:
                intersections.append((xi1, yi1))
        if 0 <= t2 <= 1:
            xi2 = x1 + t2 * dx
            yi2 = y1 + t2 * dy
            if xi2 >= 0:
                intersections.append((xi2, yi2))
        return intersections
    
    
def intersection_segments(segment1, segment2):
    """
    certains rayons n'intersectent pas la terre 
    alors ce code permet de calculer l'intersection entre deux droite pour stopper ces rayons sur l'axe des ordonnées
    """

    def orientation(p, q, r):

        val = (q[1] - p[1]) * (r[0] - q[0]) - (q[0] - p[0]) * (r[1] - q[1])
        if val == 0:
            return 0
        elif val > 0:
            return 1
        else:
            return -1

    def on_segment(p, q, r):

        if min(p[0], r[0]) <= q[0] <= max(p[0], r[0]) and min(p[1], r[1]) <= q[1] <= max(p[1], r[1]):
            return True
        return False

    p1, q1 = segment1
    p2, q2 = segment2

    o1 = orientation(p1, q1, p2)
    o2 = orientation(p1, q1, q2)
    o3 = orientation(p2, q2, p1)
    o4 = orientation(p2, q2, q1)

    # Cas généraux d'intersection
    if o1 != o2 and o3 != o4:
        # Calcul du point d'intersection
        denominator = ((q1[0] - p1[0]) * (q2[1] - p2[1])) - ((q1[1] - p1[1]) * (q2[0] - p2[0]))
        if denominator == 0:
            return None  # Les segments sont parallèles ou colinéaires
        else:
            px = ((p1[0] * q1[1] - p1[1] * q1[0]) * (q2[0] - p2[0]) - (p1[0] - q1[0]) * (p2[0] * q2[1] - p2[1] * q2[0])) / denominator
            py = ((p1[0] * q1[1] - p1[1] * q1[0]) * (q2[1] - p2[1]) - (p1[1] - q1[1]) * (p2[0] * q2[1] - p2[1] * q2[0])) / denominator
            intersection_point = (px, py)
            return intersection_point

    # Aucun des cas ci-dessus n'est vérifié, donc pas d'intersection
    return None
 

def nombre_rayon_surface(terre, intersections):
    """
    la terre est modélisée par un arc de cercle composé de segments
    les fonctions precedentes permettent de calculer l'intersection des rayons incidents avec la terre
    cette fonction permet donc de compter le nombre de rayons qui arrivent sur chaque segement de la terre
    """
    nombre_rayons_par_face = []
    for i in range(len(terre[1])-1):
        y1 = terre[1][i]
        y2 = terre[1][i+1]
        nombre_rayon_face = 0
        for j in range(len(intersections)):
            if y1 <= intersections[j][0][1] < y2:
                nombre_rayon_face +=1
        nombre_rayons_par_face.append(nombre_rayon_face)
    return nombre_rayons_par_face


#Création des objets
terre = Terre(n, r)
atmosphere = Atmosphere(N, R)
soleil_x, soleil_y = Soleil_plan(R,D)
rayons_x, rayons_y = Rayons_soleil(k, soleil_x[0], soleil_y[0], soleil_y[1], R)


angles_incidence = []
for i in range(k):
    angle = Angle_incidence(rayons_x[i], rayons_y[i])
    angles_incidence.append(angle)


angles_refracte = []
for i in range(k):
    angle = Angle_refracte(angles_incidence[i])
    angles_refracte.append(angle)
    
#coordonnées des rayons refractés apres le passage par la matrice de rotation (ne s'arretant pas sur la terre)   
x_rayons_refractes = []
y_rayons_refractes = []
for i in range (k):
    x_end, y_end, x_start, y_start = Rayon_refracte(0, 0, rayons_x[i][1], rayons_y[i][1], rayons_x[i][1], rayons_y[i][1], angles_refracte[i])
    x = [x_start, x_end]
    y = [y_start, y_end]
    x_rayons_refractes.append(x)
    y_rayons_refractes.append(y)


intersections = []
for i in range(k):
    intersection = intersection_terre_rayon(r, x_rayons_refractes[i][0], y_rayons_refractes[i][0], x_rayons_refractes[i][1], y_rayons_refractes[i][1])
    if not intersection:
            segment1 = ((0, -R), (0, R))
            segment2 = ((x_rayons_refractes[i][0], y_rayons_refractes[i][0]), (x_rayons_refractes[i][1], y_rayons_refractes[i][1]))
            intersection_point = intersection_segments(segment1, segment2)
            intersection = [intersection_point]
    intersections.append(intersection)

# coordonnées des rayons s'arretant sur la terre ou l'axe des ordonnées (grace au calcul des intersections)
x_rayons_refractes_terre = []
y_rayons_refractes_terre = []
for i in range(k):
    x_start = rayons_x[i][1]
    y_start = rayons_y[i][1]
    x_end = intersections[i][0][0]
    y_end = intersections[i][0][1]
    x = [x_start, x_end]
    y = [y_start, y_end]
    x_rayons_refractes_terre.append(x)
    y_rayons_refractes_terre.append(y)
    

nombre_rayon = nombre_rayon_surface(terre, intersections)




# Plot
# fig 1 : la modelisation avec les rayons
# fig 2 : la repartition du nombre de rayons arrivant sur chaque segement de la terre 

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))


ax1.plot(terre[0], terre[1], label='Terre')
ax1.plot(atmosphere[0], atmosphere[1], label='Atmosphère')
ax1.plot(soleil_x, soleil_y, label='Soleil')

for i in range(k):
    ax1.plot(rayons_x[i], rayons_y[i])
    ax1.plot(x_rayons_refractes_terre[i], y_rayons_refractes_terre[i])

ax1.set_aspect('equal')
ax1.set_xlabel('x')
ax1.set_ylabel('y')
ax1.legend()
ax1.grid(True)


abscisse = np.linspace(1, len(nombre_rayon), len(nombre_rayon))
ax2.plot(abscisse, nombre_rayon)
ax2.set_xlabel('Index')
ax2.set_ylabel('Nombre de Rayons')
ax2.grid(True)


plt.tight_layout()
plt.show()




# Print
# print("Angles d'incidence des rayons sur l'atmosphère (en radians):")
# for i, angle in enumerate(angles_incidence):
#     print(f"Rayon {i+1}: {angle:.2f} radians")
    
# print("Angles refracté des rayons sur l'atmosphère (en radians):")
# for i, angle in enumerate(angles_refracte):
#     print(f"Rayon {i+1}: {angle:.2f} radians")


