# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 11:45:36 2024

@author: thiba
"""

# import nécessaires
import numpy as np
import math
import matplotlib.pyplot as plt

#%% fonctions utiles pour le programme
def generate_arc_points(x, y, r, theta1, theta2, n):
    """
    Génère des points pour un arc de cercle.

    :param x: Coordonnée x du centre
    :param y: Coordonnée y du centre
    :param r: Rayon du cercle
    :param theta1: Angle de départ en radians
    :param theta2: Angle de fin en radians
    :param n: Nombre de points à générer
    :return: Liste de tuples représentant les points (x, y) sur l'arc de cercle
    """
    angles = np.linspace(theta1, theta2, n)
    points = [(x + r * np.cos(theta), y + r * np.sin(theta)) for theta in angles]
    return points

def CalculPoisitionContactAtmosphere(longueur_simulation, surface_atmosphere_modelisation, nombre_de_points):
    """
    Calcul les coordonnées des points de contact des rayons provenant du soleil et rentrant en contact avec l'atmosphere
    
    :param longueur_simulation: Longueur de la simulation entre 0 et le rayon de fin (sera pris entre -longueur_simulation et longueur_simulation)
    :param surface_atmosphere_modelisation: Liste des points selon x et y des points représentant l'atmosphère
    
    Returns
    -------
    x_rayons_atmo : Coordonnées selon x des points de contact
    y_rayons_atmo : Coordonnées selon y des points de contact

    """
    x_rayons_atmo = np.linspace(rayon_atmosphere, -rayon_atmosphere, nombre_de_points)
    y_rayons_atmo = []
    for i in range(len(surface_atmosphere_modelisation) - 1):
        x1, y1 = surface_atmosphere_modelisation[i]
        x2, y2 = surface_atmosphere_modelisation[i + 1]
        # Recherche de la fonction affine représentant la surface de l'atmo entre le ieme et le ieme+1 point
        pente_terre = (y1 - y2) / (x1 - x2)
        origine = y1 - pente_terre * x1
        for x in x_rayons_atmo:
            if x2 <= x <= x1:
                y = x * pente_terre + origine # Abscisse du point incident du ieme rayon
                y_rayons_atmo.append(y)
    return x_rayons_atmo, y_rayons_atmo


def deltaTeta(tetai):
    """
    Calcul du teta réfracté en fonction du teta incident et des différentes couches de l'atmosphère

    :param tetai: Teta incident

    Returns
    tetatot : 

    """
    teta = [tetai]
    for i in range(0,5):
        if np.abs(np.sin(teta[i-1])*ind_opt[i-1]/ind_opt[i]) > 1:
            teta.append(np.pi/2)
        else :
            tetai = np.arcsin(np.sin(teta[i-1])*ind_opt[i-1]/ind_opt[i])
            teta.append(tetai)
    l = []
    for i in range(0,5):
        li = np.tan(teta[i])*h_atm[i]
        l.append(li)
    ltot = 0
    htot = 0
    for i in range(0, 5):
        ltot = ltot + l[i]
        htot = htot + h_atm[i]
    tetatot = np.arctan(ltot/htot)
    return tetatot

def intersection(m1, b1, m2, b2):
   if m1 == m2:
       if b1 == b2:
           return "Les droites sont identiques."
       else:
           return "Les droites sont parallèles et ne se croisent pas."
   else:
       x = (b2 - b1) / (m1 - m2)
       y = m1 * x + b1
       return (x, y)


#%% execution du programme

# Paramètres pour la création des points de la Terre & de l'atmosphère
x = 0                                       # Coordonnée x du centre
y = 0                                       # Coordonnée y du centre
rayon_terre = 6371                          # Rayon de la Terre en km
rayon_atmosphere = rayon_terre + 1000       # Rayon atmosphère en km
theta1 = 0                                  # Angle de départ (en radians)
theta2 = np.pi                              # Angle de fin (en radians, ici un demi-cercle)
n = 10                                     # Nombre de points
nombre_rayons = 10 *n                      # Nombre de rayons crées
ni =1                                       # Indice optique du vide
ind_opt = [ni, 1.001032, 1.00029214, 1.0002957, 1.0002957, 1.0002957] # Indice optique du vide et des differentes couches de l'atmosphère
h_atm = [9400, 515, 35, 35, 15]           # Epaisseur des différentes couches de l'atmosphère

# Création des points de la surface de la Terre et de l'atmosphère modélisée comme un arc de cercle
surface_terre_modelisation = generate_arc_points(x, y, rayon_terre, theta1, theta2, n)
surface_atmosphere_modelisation = generate_arc_points(x, y, rayon_atmosphere, theta1, theta2, n)

# Séparation des coordonnées x et y pour la Terre et l'atmosphère
x_terre, y_terre = zip(*surface_terre_modelisation)
x_atmo, y_atmo = zip(*surface_atmosphere_modelisation)

# Modélisation du soleil à l'infini par une ligne droite
nombre_points_soleil = 1000
x_soleil = np.linspace(-10000, 10000, nombre_points_soleil)
y_soleil = [12000] * nombre_points_soleil   # y_soleil est une liste en y=12000 répété nombre_points_soleil fois

# Calcul des points de contact entre les rayons crées dans la fonction suivante
# et la surface de l'atmosphere
# les coordonnées sont stockées dans les listes x_rayons_atmo et y_rayon_atmo
x_rayons_atmo, y_rayons_atmo = CalculPoisitionContactAtmosphere(rayon_terre,
                                                                surface_atmosphere_modelisation,
                                                                nombre_rayons)

# calcul du de l'angle incident des rayons par rapport à la normale
# calcul permettant de préparer l'application de Snell-Descartes pour la déviation des rayons            
angle_theta_incident = []
for i in range(len(x_rayons_atmo)):
    theta_en_cours = -np.arcsin(x_rayons_atmo[i]/rayon_atmosphere)
    angle_theta_incident.append(theta_en_cours)
    
# calcul des points des rayons réfractés en y=0
# en se basant sur l'application de la formule de Snell-Descartes
x_rayons_terre_y0 = []
theta_refracte = []
y_rayons_terre_y0 = [0] * nombre_rayons
n1 = 1              # n de "l'espace"
n2 = 1.0003         # n de l'atmosphère (épaisseur de 7 couches simplifiée en 1 unique couche)
for i in range(len(x_rayons_atmo)):
    theta_2 = deltaTeta(angle_theta_incident[i])
    theta_refracte.append(theta_2)
    x_contact_terre = x_rayons_atmo[i]+y_rayons_atmo[i]*np.tan(theta_2-angle_theta_incident[i])
    x_rayons_terre_y0.append(x_contact_terre)

x_rayons_terre_contact = []
y_rayons_terre_contact = []
# calcul du point de contact sur Terre à partir de la position en x et y de chaque rayons sur l'atmosphère,
# l'angle réfracté, le point en y=0 de chaque rayon réfracté, le rayon de la Terre et de l'atmosphere
for i in range(len(x_rayons_atmo)):
    if np.abs(np.cos(theta_refracte[i])) < 1e-10 :
        k_en_cours = None
    else :
        print((np.cos(theta_refracte[i]),np.sqrt( (x_rayons_atmo[i]-x_rayons_terre_y0[i])**2 + (y_rayons_atmo[i]-y_rayons_terre_y0[i])**2)))
        k_en_cours = -(rayon_atmosphere-rayon_terre)/(np.cos(theta_refracte[i])*np.sqrt( (x_rayons_atmo[i]-x_rayons_terre_y0[i])**2 + (y_rayons_atmo[i]-y_rayons_terre_y0[i])**2))
    print(k_en_cours)
    if k_en_cours != None :
        h = rayon_atmosphere-rayon_terre
        x_en_cours = x_rayons_atmo[i] - h * np.sin(angle_theta_incident[i] - theta_refracte[i]) / np.cos(theta_refracte[i])
        y_en_cours = y_rayons_atmo[i] - h * np.cos(angle_theta_incident[i] - theta_refracte[i]) / np.cos(theta_refracte[i])
    else :
        x_en_cours = x_rayons_atmo[i]
        y_en_cours = y_rayons_atmo[i]
        
    x_rayons_terre_contact.append(x_en_cours)
    y_rayons_terre_contact.append(y_en_cours)

        

# comptage du nombre de rayons touchant chaque "face" de la Terre
# par face, on entend une portion droite du cercle représentant la Terre
nombre_rayons_par_face = []
for i in range(len(surface_terre_modelisation) - 1):
    x1 = surface_terre_modelisation[i][0]
    x2 = surface_terre_modelisation[i + 1][0]
    nombre_rayon_face = sum(1 for x in x_rayons_terre_contact if x2 <= x <= x1)
    nombre_rayons_par_face.append(nombre_rayon_face)

#%% affichage de la modélisation 2D

# Affichage des rayons par surface sur un graphe
abscisse = np.linspace(1, len(nombre_rayons_par_face), len(nombre_rayons_par_face))

# Affichage du modèle 2D
plt.subplot(1, 2, 1)
for i in range(len(x_rayons_atmo)):
    plt.plot([x_rayons_atmo[i], x_rayons_atmo[i]], [y_rayons_atmo [i], 12000])
    plt.plot([x_rayons_atmo[i], x_rayons_terre_contact[i]], [y_rayons_atmo[i], y_rayons_terre_contact[i]])
plt.plot(x_terre, y_terre)
plt.plot(x_atmo, y_atmo)
plt.plot(x_soleil, y_soleil)
plt.axis('equal')

# Affichage de la courbe de répartition des rayons
plt.subplot(1, 2, 2)
plt.plot(abscisse, nombre_rayons_par_face)
plt.show()
