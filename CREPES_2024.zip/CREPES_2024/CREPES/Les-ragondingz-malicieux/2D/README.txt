**Attention** : il se peut que certains modules ou certaines bibliothèque utilisées ne soient pas installées sur votre PC, dans ce cas faire un "pip intall …"

Dans les codes suivants, dans les paramètres définis au début, vous pourrez modifié le nombre de segment n représentant la Terre ainsi que le nombre de rayons k partant du soleil ou bien exécuter le code tel quel. 

Parfois les plot sont commentés pour que seul les résultats apparaissent dans la console, vous pouvez les décommenter pour avoir une visualisation graphique.

Fichier "v02.00.py" : première version 2D, utilisation de Matplotlib pour afficher une Terre, une atmosphère, un soleil et des rayons partant du soleil vers l'atmosphère, dont la direction est modifiée au passage de l'atmosphère selon Descartes. Puis comptage des rayons atteignant la Terre sur un graphe à côté. Ce code rencontre quelques problèmes.

Fichier "v02.01.py" : débogage de la v02.00.py. Dans les grandes lignes : utilisation de matrices de rotations et de dichotomie pour rendre le les variables indépendantes. Compte des rayons arrivant sur chaque segment de la Terre. Problèmes rencontrés au bords.

Fichier "v02.02.py" : débogage de la version "v02.01.py" en réglant les problèmes aux bords : modification de la manière de stopper les rayons qui ne touchent pas la Terre.

Fichier "v02.03.py" : à l'aide des versions précédentes, on calcule la puissance solaire reçue par unité de surface sur la Terre. Renvoi une liste de puissance solaire pour préparer la 3D (liste solar_power_list). Renvoi aussi la température sur chaque unité de surface en considérant la Terre comme un corps noir (albédo = 0)

Fichier "v02.04.py" : même version que la v02.03.py (renvoi les mêmes choses) en prenant en compte un albédo que l'on choisit pour la Terre entière (sable, glace, etc.) pour le calcul de la température. Vous pourrez modéifier l'albédo dans l'appel de la fonction temperature à la fin du code à partir des albédos définies dans les paramètres au début du code. 