Groupe composé de :
* Martin Gauchon
* Victor-Emmanuel Rouchon
* Bastien Serre
* Milan Richard
* Lucile Maudhuy
* Léa Robert
* Ayman Mohammedi
* Léna Lebranchu
* Alice Gouault
* Soufiane Kabchi
* Thibaud Masboeuf
* Yassin Halaouti

Dossier 1D : contient la version 1D de la modélisation
Dossier 2D : contient les différentes versions 2D de la modélisation
Dossier 3D : contient les différentes versions 3D de la modélisation
Dossier "Code préparé pour l'année prochaine" : contient les différents bout de modélisation prêts pour l'année prochaine (bouts de code qui n'ont pas pu être intégrés au code par manque de temps)
Dossier "Documentation_Validation" : contient la documentation du projet ainsi que le fichier de validation scientifique
