import numpy
import math

# permet de calculer la température de la surface
# de la Terre grâce à la formule de Stefan-Boltzmann
# sans prendre en compte l'atmosphère

puissance_recue = 342 # W/m2
rayon_terre = 6371 # km

surface_terrestre = 4*math.pi*rayon_terre**2 # km^2

# Constante de Stefan-Boltzmann
sigma = 5.68e-8 # W/m^2*K^4

T = (puissance_recue/sigma)**(1/4) # K
T = T - 273.15 # °C
print(T)
