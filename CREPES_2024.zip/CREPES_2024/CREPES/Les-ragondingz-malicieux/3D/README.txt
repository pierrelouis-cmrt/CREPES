**Attention** : il se peut que certains modules ou certaines bibliothèque utilisées ne soient pas installées sur votre PC, dans ce cas faire un "pip intall …"

Parfois, les calculs et les appels aux fonction sont lents et il sera nécessaire d'attendre quelques secondes. 

Fichier "v03.00.py" : modélisation d'une sphère qui dépend de la rotation quotidienne et saisonnière pour préparer le fichier v03.01.py. Utiliser le code tel quel.

Fichier "v03.01.py" : utilisation du modèle 2D sans albédo (albédo = 0, liste solar_power_list du code v02.03.py) pour fabriquer une version 3D qui dépend de la rotation quotidienne et saisonnière. Le bleu sur la modélisation correspond à une absence de puissance solaire reçue tandis que la partie rouge correspond à une réception. Plus le rouge est foncé, plus la puissance solaire reçue est importante. Utiliser le code tel quel.

Fichier "v03.02.py" : renvoie la puissance reçue en fonction de la latitude et de la longitude (à appeler à la main) en se basant sur les autres versions.

Fichier "v03.03.py" : affiche un planisphère 2D et renvoie, en fonction du clic sur la carte, la latitude, la longitude, l'albédo moyen sur 2022-2023 en ce point et la température de ce point. Le renvoi de la réponse se fait dans la console. 
