
import matplotlib.cm as cm
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.widgets import Slider

# Création des coordonnées de latitude et de longitude pour la sphère
phi = np.linspace(0, np.pi, 200)   # Latitude
theta = np.linspace(0, 2 * np.pi, 400)  # Longitude

phi, theta = np.meshgrid(phi, theta)

# Rayon de la sphère
r = 1

# Conversion des coordonnées sphériques en coordonnées cartésiennes
x = r * np.sin(phi) * np.cos(theta)
y = r * np.sin(phi) * np.sin(theta)
z = r * np.cos(phi)

# Inclinaison de l'axe de rotation de la Terre en degrés
inclination_deg = 23.5
inclination_rad = np.deg2rad(inclination_deg)

# Position initiale du Soleil
sun_direction = np.array([1, 0, 0])  # Le Soleil est à droite

# Liste de la puissance solaire pour chaque angle d'incidence calculée avec le code 2D v02.05.py
solar_power_list = [340.99791305990425, 340.9729166645948, 340.8980678541917, 340.7737118874391, 340.60015133377516, 340.3779072707455, 340.1081098415972, 339.7914886896424, 339.4287788502358, 339.02141831611664, 338.5711478422808, 338.0795524927111, 337.54787283882564, 336.97839747882995, 336.3731080161511, 335.73415858794164, 335.0637956318708, 334.3637442330852, 333.63713292913843, 332.8873648199595, 332.11650935252146, 331.32662915815945, 330.5214746934493, 329.7050456437189, 328.8787592394777, 328.04583629742774, 327.21053860969903, 326.37530874220215, 325.5435828354899, 324.71887413530624, 323.9047423991284, 323.1036479911244, 322.3179769322534, 321.5524549245715, 320.8106786055482, 320.09375873770784, 319.4051610920102, 318.7483293738928, 318.12668457332785, 317.5422566649898, 316.99695603291565, 316.49391531758806, 316.03342225629154, 315.61836037276237, 315.2529069998112, 314.9369161381938, 314.67003369910486, 314.45599804068183, 314.295545339271, 314.18635569354115, 314.13166702503634]

def compute_temperature(x, y, z, sun_direction, solar_power_list):
    # Normaliser les vecteurs de la surface
    normals = np.array([x, y, z])
    norms = np.linalg.norm(normals, axis=0)
    normals /= norms

    # Normaliser la direction du soleil
    sun_dir_normalized = sun_direction / np.linalg.norm(sun_direction)

    # Constante de Stefan-Boltzmann
    sigma = 5.67e-8

    # Calcul de l'angle d'incidence (cosinus de l'angle)
    cos_incidence = np.sum(normals * sun_dir_normalized[:, np.newaxis, np.newaxis], axis=0)
    cos_incidence = np.clip(cos_incidence, 0, 1)  # Forcer à être dans l'intervalle [0, 1]

    # Interpolation linéaire des puissances solaires
    angles = np.linspace(0, 90, len(solar_power_list))  # Angles de 0 à 90 degrés
    solar_power_interpolated = np.interp(np.degrees(np.arccos(cos_incidence)), angles, solar_power_list)
    
    # Mettre la puissance à zéro pour la moitié de la sphère à l'ombre
    dot_product = np.sum(normals * sun_dir_normalized[:, np.newaxis, np.newaxis], axis=0)
    solar_power_interpolated[dot_product <= 0] = 0

    # Calcul de la température en Kelvin
    temperature = (solar_power_interpolated / sigma) ** 0.25

    return temperature

def update_colors(temperature):
    norm = plt.Normalize(vmin=np.min(temperature), vmax=np.max(temperature))
    colors = cm.coolwarm(norm(temperature))
    return colors

def rotate(angle, season_angle):
    angle = np.deg2rad(angle)
    season_angle = np.deg2rad(season_angle)
    
    # Matrice de rotation autour de l'axe Z (rotation quotidienne)
    R_z = np.array([[np.cos(angle), -np.sin(angle), 0],
                    [np.sin(angle),  np.cos(angle), 0],
                    [0,              0,             1]])

    # Matrice de rotation autour de l'axe X (inclinaison)
    R_x = np.array([[1, 0, 0],
                    [0, np.cos(inclination_rad), -np.sin(inclination_rad)],
                    [0, np.sin(inclination_rad),  np.cos(inclination_rad)]])

    # Matrice de rotation autour de l'axe Y (modélisation des saisons)
    R_y = np.array([[np.cos(season_angle), 0, np.sin(season_angle)],
                    [0, 1, 0],
                    [-np.sin(season_angle), 0, np.cos(season_angle)]])

    # Appliquer les rotations : quotidienne, puis saisonnière, puis inclinaison
    coords = np.array([x.flatten(), y.flatten(), z.flatten()])
    coords = R_y @ (R_x @ (R_z @ coords))
    x_rot = coords[0].reshape(x.shape)
    y_rot = coords[1].reshape(y.shape)
    z_rot = coords[2].reshape(z.shape)

    lighting = compute_temperature(x_rot, y_rot, z_rot, sun_direction, solar_power_list)
    colors = update_colors(lighting)

    ax.cla()
    ax.grid(True, color='lightgray')  # Cadre en gris clair
    ax.plot_surface(x_rot, y_rot, z_rot, facecolors=colors, rstride=5, cstride=5, alpha=1, edgecolor='none')
    
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    plt.draw()

# Fonction de mise à jour pour le curseur de rotation quotidienne
def update_daily_rotation(val):
    global daily_angle
    daily_angle = val
    rotate(daily_angle, seasonal_angle)

# Fonction de mise à jour pour le curseur de rotation saisonnière
def update_seasonal_rotation(val):
    global seasonal_angle
    seasonal_angle = val
    rotate(daily_angle, seasonal_angle)

# Configuration initiale du tracé
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Ajustement de l'espace pour les curseurs
plt.subplots_adjust(bottom=0.35)

# Initialisation des angles de rotation
daily_angle = 0
seasonal_angle = 0

# Initialisation de la sphère
rotate(daily_angle, seasonal_angle)

# Création des curseurs
ax_daily_angle = plt.axes([0.25, 0.2, 0.65, 0.03], facecolor='lightgoldenrodyellow')
angle_slider = Slider(ax=ax_daily_angle, label='Angle de rotation quotidienne', valmin=0, valmax=360, valinit=0)
angle_slider.on_changed(update_daily_rotation)

ax_seasonal_angle = plt.axes([0.25, 0.1, 0.65, 0.03], facecolor='lightgoldenrodyellow')
season_slider = Slider(ax=ax_seasonal_angle, label='Angle de rotation saisonnière', valmin=-23.5, valmax=23.5, valinit=0)
season_slider.on_changed(update_seasonal_rotation)

plt.show()
