
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# Paramètres du modèle
alpha = 1e-5  # Diffusivité thermique (m^2/s)
radius = 100  # Rayon du demi-cercle
theta = np.linspace(0, np.pi, 11)  # Angles pour le demi-cercle
dx = np.pi * radius / (len(theta) - 1)
dt = dx**2 / (4 * alpha) / 10  # Pas de temps adapté
time_steps = 2000  # Nombre de pas de temps

# Températures initiales spécifiées sur le demi-cercle
initial_temperatures = np.array([-68.21421297, -54.3240503, -40.93248043, -30.94691359, -24.93632925,
                                 -22.93869904, -24.93632925, -30.94691359, -40.93248043, -54.3240503,
                                 -68.21421297])

# Coordonnées x et y pour les points avec des températures initiales
x = radius * np.cos(theta)
y = radius * np.sin(theta)

# Condition initiale : assigner les températures initiales aux points correspondants
T = initial_temperatures.copy()

# Création de la figure pour l'animation
fig, ax = plt.subplots(figsize=(10, 6))
scat = ax.scatter(x, y, c=T, cmap='inferno', vmin=np.min(initial_temperatures), vmax=np.max(initial_temperatures))
line, = ax.plot(x, y, label='Surface du demi-cercle', color='black')
cbar = plt.colorbar(scat, ax=ax, label='Température (°C)')
ax.set_xlabel('Position x')
ax.set_ylabel('Position y')
ax.set_title('Diffusion de la température à la surface du demi-cercle')
ax.legend()
ax.set_aspect('equal')

# Fonction d'animation
def update(frame):
    global T
    T_new = T.copy()
    T_new[1:-1] = T[1:-1] + alpha * dt / dx**2 * (T[2:] - 2*T[1:-1] + T[:-2])
    T_new[0] = T[0] + alpha * dt / dx**2 * (T[1] - T[0])
    T_new[-1] = T[-1] + alpha * dt / dx**2 * (T[-2] - T[-1])
    T = T_new
    scat.set_array(T)
    return scat,

# Création de l'animation
ani = animation.FuncAnimation(fig, update, frames=range(time_steps), interval=50, blit=False)
plt.show()
