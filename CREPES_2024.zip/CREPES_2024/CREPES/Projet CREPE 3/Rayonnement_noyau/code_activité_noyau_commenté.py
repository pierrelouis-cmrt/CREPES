import numpy as np

### Paramètres

rayon_terre = 6371e3  # en mètres
epaisseur_croute = 35e3  # en mètres
flux_geothermique_moyen = 0.065  # W/m^2


### Calcul du flux de chaleur

def flux_geothermique(rayon, conductivite, epaisseur):
    surface_sphere = 4 * np.pi * rayon**2
    flux = flux_geothermique_moyen * surface_sphere
    return flux

# Cette fonction calcule le flux total de chaleur géothermique sortant de la surface de la Terre, à partir de l'aire d'une sphère dont le rayon est réduit par l'épaisseur de la croûte (ce qui est une simplification).



flux_total = flux_geothermique(rayon_terre - epaisseur_croute, conductivite_thermique, epaisseur_croute)
print(f"Flux de chaleur géothermique total : {flux_total / 1e12:.2f} TW")


# Le rayon ajusté (rayon_terre - epaisseur_croute) représente une simplification. En réalité, le flux géothermique pourrait varier en fonction de divers facteurs géologiques non pris en compte ici.

# Ce code est utile pour estimer le flux géothermique total qui sort de la Terre. Il est à noter que le code utilise des valeurs moyennes et simplifie la complexité réelle des propriétés géothermiques de la Terre.