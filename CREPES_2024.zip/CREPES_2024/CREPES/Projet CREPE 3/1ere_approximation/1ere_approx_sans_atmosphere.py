import numpy as np



R = 6.37e6 # rayon Terre

D = 1.5e11 # distance Terre - Soleil

sigma = 5.670374e-8 #(W.m^-2.K^-4)

A = 0.3 # moyen(sol + nuage)

P = 3.845e26 #(W)



S_sphere = 4 * np.pi * D**2

S_disque = np.pi * R**2

S_terre = 4 * np.pi * R**2



Ps = P / S_sphere # puissance surfacique (W.m^-2)



Pr = Ps * S_disque # puissance reçue (W)



Pabs = (1 - A) * Pr / S_terre # puissance réelle surfacique absorbée par la Terre (W.m^-2)



# Loi de Stefan-Boltzman

T = (Pabs / sigma)**0.25 - 273.15



print(T)