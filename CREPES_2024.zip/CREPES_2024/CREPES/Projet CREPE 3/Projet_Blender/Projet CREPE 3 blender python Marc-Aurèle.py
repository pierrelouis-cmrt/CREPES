#Code de Marc-Aurèle Fernandez--Inurrieta
import bpy
import bmesh
import math as m
import mathutils
import numpy as np

R = 6371000 # Rayon de la Terre
Pr_earth = (1.74*10**17)/(m.pi*(R**2)) # Puissance reçue par la terre du soleil
epsilon = 10**(-3)

# get reference to Earth object (has to be the active one)
earth = bpy.context.active_object

# create new bmesh object
bm = bmesh.new()
bm.from_mesh(earth.data)

#dark = bpy.data.materials.new("dark")
#dark.diffuse_color = (0, 0, 0, 1)
#earth.data.materials.append(dark)

#light = bpy.data.materials.new("light")
#light.diffuse_color = (250, 250, 250, 1)
#earth.data.materials.append(light)

#glace = bpy.data.materials.new("glace")
#glace.diffuse_color = (173, 216, 230, 1)
#earth.data.materials.append(glace)

#eau =  bpy.data.materials.new("eau")
#eau.diffuse_color = (0, 0, 139, 1)
#earth.data.materials.append(eau)

#neige =  bpy.data.materials.new("neige")
#neige.diffuse_color = (255, 255, 255, 1)
#earth.data.materials.append(neige)

#desert =  bpy.data.materials.new("desert")
#desert.diffuse_color = (255, 255, 0, 1)
#earth.data.materials.append(desert)
#    
#foret =  bpy.data.materials.new("foret")
#foret.diffuse_color = (0, 255, 0, 1)
#earth.data.materials.append(foret)

#terre =  bpy.data.materials.new("terre")
#terre.diffuse_color = (93, 64, 51, 1)
#earth.data.materials.append(terre)


class Sections:
    def __init__(self, face):
        self._face = face
        self._center = face.calc_center_median()
        self._center_spherical = self.cartesian_to_spherical()
        self.Pr_face = 0
        self.albedo = self.calcul_albedo()
        
    def cartesian_to_spherical(self):
        rho = m.sqrt(self._center[0]**2 + self._center[1]**2 + self._center[2]**2)
        lat = m.pi/2 - m.acos(self._center[2] / rho)  # calculation of latitude
        long = m.atan2(self._center[1], self._center[0])  # calculation of longitude
        return [rho, lat , long]
    
    def change_color(self):
        if self.albedo == 0.60:
            self._face.material_index = 2
        elif self.albedo == 0.10:
            self._face.material_index = 3
        elif self.albedo == 0.80:
            self._face.material_index = 4
        elif self.albedo == 0.35:
            self._face.material_index = 5
        elif self.albedo ==0.20:
            self._face.material_index = 6
        elif self.albedo == 0.15:
            self._face.material_index = 7        
    
    
    
    def calcul_albedo(self):
        glace = 0.60
        eau = 0.10
        neige = 0.80
        desert = 0.35
        foret = 0.20
        terre = 0.15
        

        lat = m.degrees(self._center_spherical[1])
        lng = m.degrees(self._center_spherical[2])
        
        if lng <= 60 and lng >= 40 and lat <= 40 and lat >= 20:
            return terre
        elif lng>=-20 and lng<=0 and lat>=20 and lat<=30:
            return desert
        elif lng<=-60 and lng>=-80 and lat>=-70 and lat<=-50:
            return eau
        elif lat >= 65 or lat <= -65:
            return glace
        elif lng >= 160 or lng <= -140:
            return eau
        elif lng <= -120 and lng >= -140 and lat >= -65 and lat <= 50:
            return eau
        elif lng <= -80 and lng >= -120 and lat >= -65 and lat <= 20:
            return eau
        elif lng <= 140 and lng >= -60 and lat >= -65 and lat <= -30:
            return eau
        elif lng <= -60 and lng >= -80 and lat >= 10 and lat <= 40:
            return eau
        elif lng <= 0 and lng >= -60 and lat >= 30 and lat <= 65:
            return eau
        elif lng <= -20 and lng >= -60 and lat >= 10 and lat <= 30:
            return eau
        elif lng <= 10 and lng >= -60 and lat >= 0 and lat <= 10:
            return eau
        elif lng <= 10 and lng >= -40 and lat >= -30 and lat <= 0:
            return eau
        elif lng <= 120 and lng >= 40 and lat >= 10 and lat <= 20:
            return eau
        elif lng <= 100 and lng >= 40 and lat >= -30 and lat <= 10:
            return eau
        elif lng <= 120 and lng >= 100 and lat >= -30 and lat <= -10:
            return eau
        elif lng <= 140 and lng >= 120 and lat >= 0 and lat <= 30:
            return eau
        elif lng <= 160 and lng >= 140 and lat >= 0 and lat <= 60:
            return eau
        elif lng <= -60 and lng >= -80 and lat <= 10 and lat >= 0:
            return foret
        elif lng <= -40 and lng >= -80 and lat <= 0 and lat >= -30:
            return foret
        elif lng <= -60 and lng >= -80 and lat <= -30 and lat >= -65:
            return foret
        elif lng <= 40 and lng >= -20 and lat <= 20 and lat >= -10:
            return foret
        elif lng <= 140 and lng >= 100 and lat <= 40 and lat >= 30:
            return foret
        elif lng <= 120 and lng >= 100 and lat <= 30 and lat >= 0:
            return foret
        elif lng <= 160 and lng >= 100 and lat <= 0 and lat >= -10:
            return foret
        elif lng <= 40 and lng >= 10 and lat <= -10 and lat >= -30:
            return desert
        elif lng <= 60 and lng >= 0 and lat <= 40 and lat >= 20:
            return desert
        elif lng <= 160 and lng >= 120 and lat <= -10 and lat >= -30:
            return desert
        elif lng <= -80 and lng >= -120 and lat <= 50 and lat >= 20:
            return terre
        elif lng <= 140 and lng >= 0 and lat <= 60 and lat >= 30:
            return terre
        elif lng>=60 and lng<=100 and lat>=20 and lat<=30:
            return terre
        elif lng>=140 and lng<=160 and lat<=-30 and lat>=-70:
            return eau        
        else:
            return neige

Grids = [Sections(i) for i in bm.faces]

def effacer(Section):
    for i in Section:
        i._face.material_index = 0
        


# changement de position de la terre + calcul de la puissance reçue par une surface
def earth_reposition(day, hour, Section,puiss):
    effacer(Section)
    earth.rotation_euler.y = ((23.5*m.pi)/180)*m.cos((2*m.pi*day)/365)    # calcul de l'inclinaison de l'axe de la Terre
    #earth.rotation_euler.z = ((hour)/24)*2*m.pi
    b = 0
    c = 0
    d = 0
    
    for i in Section:
        er = np.array([m.sin(earth.rotation_euler.y+(m.pi/2)-i._center_spherical[1])*m.cos(i._center_spherical[2]), m.sin(earth.rotation_euler.y+(m.pi/2)-i._center_spherical[1])*m.sin(i._center_spherical[2]), m.cos(earth.rotation_euler.y+(m.pi/2)-i._center_spherical[1])])
        if i._center_spherical[1] > (m.pi/2 - earth.rotation_euler.y) and i._center_spherical[1] < (m.pi/2):
            i._face.material_index = 1
            vec = np.dot(er, puiss)
            i.Pr_face = vec*(R**2)*sin(earth.rotation_euler.y+(m.pi/2)-i._center_spherical[1])
            b += 1
        
        elif i._center_spherical[2] > (-((hour-8)*(2*m.pi))/24) and i._center_spherical[2] < (m.pi - ((hour - 8)*2*m.pi)/24):
            i._face.material_index = 1
            vec = np.dot(er, puiss)
            i.Pr_face = vec*(R**2)*m.sin(earth.rotation_euler.y+(m.pi/2)-i._center_spherical[1])
            c += 1
        else:
            i.Pr_face = 0
            d += 1
    print(f"1st {b} 2nd {c} none {d} total {len(Section)})")
    
#earth_reposition(200, 10 , Grids, 100)
for i in Grids:
    i.change_color()

    
bm.to_mesh(earth.data)  # update mesh data in Blender

bm.free()