import matplotlib.pyplot as plt

# Les données de la courbe estimées manuellement
data = [
    {"wavelength_microns": 0.0, "transmittance": 0.0},
    {"wavelength_microns": 0.5, "transmittance": 0.6},
    {"wavelength_microns": 1.0, "transmittance": 0.75},
    {"wavelength_microns": 1.5, "transmittance": 0.5},
    {"wavelength_microns": 2.0, "transmittance": 0.65},
    {"wavelength_microns": 2.5, "transmittance": 0.4},
    {"wavelength_microns": 3.0, "transmittance": 0.7},
    {"wavelength_microns": 3.5, "transmittance": 0.2},
    {"wavelength_microns": 4.0, "transmittance": 0.6},
    {"wavelength_microns": 4.5, "transmittance": 0.1},
    {"wavelength_microns": 5.0, "transmittance": 0.45},
    {"wavelength_microns": 5.5, "transmittance": 0.1},
    {"wavelength_microns": 6.0, "transmittance": 0.2},
    {"wavelength_microns": 6.5, "transmittance": 0.1},
    {"wavelength_microns": 7.0, "transmittance": 0.3},
    {"wavelength_microns": 7.5, "transmittance": 0.15},
    {"wavelength_microns": 8.0, "transmittance": 0.35},
    {"wavelength_microns": 8.5, "transmittance": 0.5},
    {"wavelength_microns": 9.0, "transmittance": 0.45},
    {"wavelength_microns": 9.5, "transmittance": 0.55},
    {"wavelength_microns": 10.0, "transmittance": 0.4},
    {"wavelength_microns": 10.5, "transmittance": 0.5},
    {"wavelength_microns": 11.0, "transmittance": 0.3},
    {"wavelength_microns": 11.5, "transmittance": 0.45},
    {"wavelength_microns": 12.0, "transmittance": 0.1},
    {"wavelength_microns": 12.5, "transmittance": 0.35},
    {"wavelength_microns": 13.0, "transmittance": 0.05},
    {"wavelength_microns": 13.5, "transmittance": 0.25},
    {"wavelength_microns": 14.0, "transmittance": 0.0},
    {"wavelength_microns": 14.5, "transmittance": 0.15},
    {"wavelength_microns": 15.0, "transmittance": 0.05},
    {"wavelength_microns": 15.5, "transmittance": 0.1},
    {"wavelength_microns": 16.0, "transmittance": 0.0},
    {"wavelength_microns": 16.5, "transmittance": 0.05},
    {"wavelength_microns": 17.0, "transmittance": 0.0},
    {"wavelength_microns": 17.5, "transmittance": 0.05},
    {"wavelength_microns": 18.0, "transmittance": 0.0},
    {"wavelength_microns": 18.5, "transmittance": 0.05},
    {"wavelength_microns": 19.0, "transmittance": 0.0},
    {"wavelength_microns": 19.5, "transmittance": 0.05},
    {"wavelength_microns": 20.0, "transmittance": 0.0}
]

# Extraction des valeurs pour le tracé
wavelengths = [point["wavelength_microns"] for point in data]
transmittances = [point["transmittance"] for point in data]

# Tracer la courbe
plt.figure(figsize=(10, 6))
plt.plot(wavelengths, transmittances, label="Transmittance", color='b')
plt.xlabel("WAVELENGTH (microns)")
plt.ylabel("TRANSMITTANCE")
plt.title("Transmittance")
plt.grid(True)
plt.legend()
plt.show()
