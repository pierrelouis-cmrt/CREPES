import numpy as np
import pandas as pd
import cv2
import matplotlib.pyplot as plt
from scipy import integrate

image_path = "C:/Users/loanl/Pictures/thumbnail_image2.png"
h = 6.626e-34  # Constante de Planck en J·s
c = 3e8        # Vitesse de la lumière en m/s
k_B = 1.381e-23  # Constante de Boltzmann en J/K
T = [5778, 288]     

def get_points(image_path):
    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 100]

    points = []
    for contour in filtered_contours:
        for point in contour:
            x, y = point[0]
            points.append((x, y))

    height, width, _ = image.shape
    min_x, max_x = 0.2, 20.0
    min_y, max_y = 0.0, 0.9  

    graph_points = []
    for (x, y) in points:
        graph_x = min_x + (max_x - min_x) * x / width
        graph_y = max_y - (max_y - min_y) * y / height
        graph_points.append((graph_x, graph_y))
    return graph_points

def get_abscissa_ordinate(graph_points, nb_points):
    abscissa = []
    ordinate = []
    for i in range(0, nb_points):
        abscissa.append(graph_points[i][0])
        ordinate.append(graph_points[i][1])
    return (abscissa, ordinate)

def planck_after_atm(wavelength, temperature, coeff):
    return coeff * planck_before_atm(wavelength, temperature)

def planck_before_atm(wavelength, temperature):
    return (2 * h * c**2) / ((wavelength *10**-6)**5) * (1 / (np.exp((h * c) / (wavelength*10**-6 * k_B * temperature)) - 1))

def power(graph_points, nb_points, abscissa):
    planck = []
    for j in range(0, 2):
        planck_after_atm_list = []
        for i in range(0, nb_points):
            planck_after_atm_list.append(planck_after_atm(graph_points[i][0], T[j], graph_points[i][1]))
        print(len(planck_after_atm_list))
        planck.append(integrate.simpson(planck_after_atm_list, abscissa))
    return planck

graph_points = get_points(image_path)
abscissa = get_abscissa_ordinate(graph_points, len(graph_points))[0]
print(len(abscissa))
print(power(graph_points, len(graph_points), abscissa))

list1 = []
list2 = []
list3 = []
list4 = []
for i in range(0, len(graph_points)):
    list1.append(planck_before_atm(graph_points[i][0], T[0]))
    list2.append(planck_after_atm(graph_points[i][0], T[0], graph_points[i][1]))
    list3.append(planck_before_atm(graph_points[i][0], T[1]))
    list4.append(planck_after_atm(graph_points[i][0], T[1], graph_points[i][1]))

plt.plot(abscissa, list1)
plt.plot(abscissa, list2)
plt.show()

plt.plot(abscissa, list3)
plt.plot(abscissa, list4)
plt.show()
