import numpy as np
import matplotlib.pyplot as plt
from scipy.constants import h, c, k

# Constantes
T_sun = 5778  # Température du Soleil en Kelvin
T_earth = 288  # Température de la Terre en Kelvin
wavelengths = np.linspace(1e-9, 1e-4, 1000)  # Longueurs d'onde de 1 nm à 0.1 mm

# Fonction pour calculer la distribution spectrale de Planck
def planck(wavelength, T):
    # Calcul de l'émission selon la loi de Planck
    return (2*h*c**2) / (wavelength**5) / (np.exp((h*c) / (wavelength*k*T)) - 1)

# Calcul des spectres
spectrum_sun = planck(wavelengths, T_sun)
spectrum_earth = planck(wavelengths, T_earth)

# Tracé des spectres sur deux graphiques
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 12))

# Plot pour le spectre du Soleil
ax1.plot(wavelengths*1e9, spectrum_sun, label="Soleil (T=5778K)", color='orange')
ax1.set_yscale('log')
ax1.set_xlabel("Longueur d'onde (nm)")
ax1.set_ylabel("Émission spectrale (W·sr⁻¹·m⁻³)")
ax1.set_title("Spectre d'émission du Soleil")
ax1.legend()
ax1.grid(True)

# Plot pour le spectre de la Terre
ax2.plot(wavelengths*1e9, spectrum_earth, label="Terre (T=288K)", color='blue')
ax2.set_yscale('log')
ax2.set_xlabel("Longueur d'onde (nm)")
ax2.set_ylabel("Émission spectrale (W·sr⁻¹·m⁻³)")
ax2.set_title("Spectre d'émission de la Terre")
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.show()

