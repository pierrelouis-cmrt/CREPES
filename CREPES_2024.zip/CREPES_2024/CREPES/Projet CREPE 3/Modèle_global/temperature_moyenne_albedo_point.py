import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# Constantes
R = 6.37e6  # rayon Terre en mètres
D = 1.5e11  # distance Terre-Soleil en mètres
sigma = 5.670374e-8  # constante de Stefan-Boltzmann en W.m^-2.K^-4
P = 3.845e26  # puissance du Soleil en watts
G = 155  # puissance thermique due à l'effet de serre en W/m²

# Fonction pour calculer l'albédo en fonction de la latitude et de la longitude
#differentes valeurs d'albedo
glace = 0.60
eau = 0.10
neige = 0.80
desert = 0.35
foret = 0.20
terre = 0.15


##Albédo (code réutilisé d'un notre modèle)
def albedo(lat, lng):
    if lat >= 65 or lat <= -65 :
        return glace

    elif lng >= 160 or lng <= -140 :
        return eau

    elif lng <= -120 and lng >= -140 and lat >= -65 and lat <= 50 :
        return eau

    elif lng <= -80 and lng >= -120 and lat >= -65 and lat <= 20 :
        return eau

    elif lng <= 140 and lng >= -60 and lat >= -65 and lat <= -30 :
        return eau

    elif lng <= -60 and lng >= -80 and lat >= 10 and lat <= 40 :
        return eau

    elif lng <= 0 and lng >= -60 and lat >= 30 and lat <= 65 :
        return eau

    elif lng <= -20 and lng >= -60 and lat >= 10 and lat <= 30 :
        return eau

    elif lng <= 10 and lng >= -60 and lat >= 0 and lat <= 10 :
        return eau

    elif lng <= 10 and lng >= -40 and lat >= -30 and lat <= 0 :
        return eau

    elif lng <= 120 and lng >= 40 and lat >= 10 and lat <= 20 :
        return eau

    elif lng <= 100 and lng >= 40 and lat >= -30 and lat <= 10 :
        return eau

    elif lng <= 120 and lng >= 100 and lat >= -30 and lat <= -10 :
        return eau

    elif lng <= 140 and lng >= 120 and lat >= 0 and lat <= 30 :
        return eau

    elif lng <= 160 and lng >= 140 and lat >= 0 and lat <= 60 :
        return eau
    elif lng <= -60 and lng >= - 80 and lat<= 10 and lat >= 0 :
       return foret
    elif lng <= -40 and lng >= - 80 and lat <= 0 and lat >= -30 :
        return foret
    elif lng <= -60 and lng >= - 80 and lat <= -30 and lat >= -65 :
        return foret
    elif lng <= 40 and lng >= - 20 and lat <= 20  and lat >= -10 :
        return foret
    elif lng <= 140 and lng >= 100 and lat<= 40 and lat >= 30 :
        return foret
    elif lng <= 120 and lng >= 100 and lat<= 30 and lat >= 0 :
        return foret
    elif lng <= 160 and lng >= 100 and lat<= 0 and lat >= -10 :
        return foret
    elif lng <= 40 and lng >= 10 and lat<= -10 and lat >= -30 :
        return desert
    elif lng <= 60 and lng >= 0 and lat<= 40 and lat >= 20 :
        return desert
    elif lng <= 160 and lng >= 120 and lat<= -10 and lat >= -30 :
        return desert
    elif lng <= -80 and lng >= - 120 and lat<= 50 and lat >= 20 :
        return terre
    elif lng <= 140 and lng >= 0 and lat<= 60 and lat >= 30 :
        return terre
    elif lng <= 60 and lng >= 40 and lat<= 40 and lat >= 20 :
        return terre
    elif lng <= 100 and lng >= 40 and lat<= 40 and lat >= 20 :
        return terre
    else:
        return neige

##Fonction température et les moyennes
#Fonction pour calculer la température en fonction de la latitude et de la longitude

def temperature(lat, lon):
    # Calcul de l'albédo à cet endroit
    A = albedo(lat, lon)

    # Puissance surfacique solaire en W/m²
    Ps = P / (4 * np.pi * D**2)

    # Puissance totale reçue par la Terre en W
    Pr = Ps * np.pi * R**2

    # Puissance réelle surfacique absorbée par la Terre en W/m²
    Pabs = (1 - A) * Pr / (4 * np.pi * R**2)

    # Ajout de l'effet de serre
    Pabs += G

    # Température en Kelvin
    T_kelvin = (Pabs / sigma)**0.25

    # Conversion en Celsius
    T_celsius = T_kelvin - 273.15

    return T_celsius


# Fonction pour calculer la température moyenne globale
def temperature_moyenne_globale():
    lats = np.linspace(-90, 90, 180)  # Divise la latitude en 180 points
    lons = np.linspace(-180, 180, 360)  # Divise la longitude en 360 points
    total_temp = 0
    count = 0

    for lat in lats:
        for lon in lons:
            total_temp += temperature(lat, lon)
            count += 1

    return total_temp / count

def albedo_moyen_global():
    lats = np.linspace(-90, 90, 180)  # Divise la latitude en 180 points
    lons = np.linspace(-180, 180, 360)  # Divise la longitude en 360 points
    total_albedo = 0
    count = 0

    for lat in lats:
        for lon in lons:
            total_albedo += albedo(lat, lon)
            count += 1

    return total_albedo / count

##Carte

# Calculer et afficher l'albédo moyen global
alb_moyen = albedo_moyen_global()
print(f'Albédo moyen global: {alb_moyen:.2f}')

# Calculer et afficher la température moyenne globale
temp_moyenne = temperature_moyenne_globale()
print(f'Température moyenne globale: {temp_moyenne:.2f} °C')

# Création de la carte
plt.figure(figsize=(12, 6))
m = Basemap(projection='cyl', llcrnrlat=-90, urcrnrlat=90,
            llcrnrlon=-180, urcrnrlon=180, resolution='c')

# Dessiner les contours de la carte
m.drawcoastlines()
m.drawcountries()
m.drawparallels(np.arange(-90., 91., 30.), labels=[1,0,0,0])
m.drawmeridians(np.arange(-180., 181., 60.), labels=[0,0,0,1])

# Titre de la carte
plt.title('Cliquez sur un endroit pour obtenir la température')

# Initialisation de l'annotation de la température
temperature_text = plt.text(0.02, 0.95, '', transform=plt.gca().transAxes)

# Affichage de la température moyenne globale sur la carte
average_temp_text = plt.text(0.02, 0.90, f'Température moyenne globale: {temp_moyenne:.2f} °C', transform=plt.gca().transAxes)

# Fonction pour gérer le clic et afficher la température
def onclick(event):
    if event.xdata is not None and event.ydata is not None:
        lon, lat = m(event.xdata, event.ydata, inverse=True)
        temp = temperature(lat, lon)
        alb = albedo(lat, lon)
        temperature_text.set_text(f'Latitude: {lat:.2f}\nLongitude: {lon:.2f}\nTempérature: {temp:.2f} °C\nAlbédo: {alb:.2f}')
        plt.draw()

plt.gcf().canvas.mpl_connect('button_press_event', onclick)

plt.show()
