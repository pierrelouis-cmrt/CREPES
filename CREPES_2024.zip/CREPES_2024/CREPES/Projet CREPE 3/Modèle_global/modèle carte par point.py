from math import cos, sin, pi
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs

stef = 5.67e-8 #constante stefan boltzmann

def convertir(degres):
    """permet de convertir une valeur en degrés en radiant"""
    rad=(degres*2*pi)/360
    return rad

alpha = convertir(23.5) #angle Terre
R = 6371000 #rayon de la Terre

#albédo
glace = 0.60
eau = 0.10
neige = 0.80
desert = 0.35
foret = 0.20
terre = 0.15

def B_point(j):
    '''Calcule angle entre l'inclinaison entre l'axe de rotation de la Terre autour d'elle même et celui autour du Soleil'''
    return alpha*cos(2*pi*j/365)

def dpuiss(lat, lng, h, j, puiss):
    '''Puissance reçu par une maille avec er la projection du vecteur de la base sphérique dans la base cartesienne'''
    B = B_point(j)

    er = np.array([cos(lng+((h - 8) * 2 * pi / 24)-pi/2) * sin(B + (pi / 2) - lat), sin(B + (pi / 2) - lat) * sin(lng+((h - 8) * 2 * pi / 24)-pi/2), cos((B + (pi / 2) - lat))])

    vec = np.dot(er, puiss)

    if vec <= 0 :
        return abs(vec)

    else :
        return 0

def albedo(lat, lng):
    '''Retourne l'albedo d'une maille en fonction de sa latitude et de sa longitude'''

    if lat >= 65 or lat <= -65 :
        return glace

    elif lng >= 160 or lng <= -140 :
        return eau

    elif lng <= -120 and lng >= -140 and lat >= -65 and lat <= 50 :
        return eau

    elif lng <= -80 and lng >= -120 and lat >= -65 and lat <= 20 :
        return eau

    elif lng <= 140 and lng >= -60 and lat >= -65 and lat <= -30 :
        return eau

    elif lng <= -60 and lng >= -80 and lat >= 10 and lat <= 40 :
        return eau

    elif lng <= 0 and lng >= -60 and lat >= 30 and lat <= 65 :
        return eau

    elif lng <= -20 and lng >= -60 and lat >= 10 and lat <= 30 :
        return eau

    elif lng <= 10 and lng >= -60 and lat >= 0 and lat <= 10 :
        return eau

    elif lng <= 10 and lng >= -40 and lat >= -30 and lat <= 0 :
        return eau

    elif lng <= 120 and lng >= 40 and lat >= 10 and lat <= 20 :
        return eau

    elif lng <= 100 and lng >= 40 and lat >= -30 and lat <= 10 :
        return eau

    elif lng <= 120 and lng >= 100 and lat >= -30 and lat <= -10 :
        return eau

    elif lng <= 140 and lng >= 120 and lat >= 0 and lat <= 30 :
        return eau

    elif lng <= 160 and lng >= 140 and lat >= 0 and lat <= 60 :
        return eau
    elif lng <= -60 and lng >= - 80 and lat<= 10 and lat >= 0 :
       return foret
    elif lng <= -40 and lng >= - 80 and lat <= 0 and lat >= -30 :
        return foret
    elif lng <= -60 and lng >= - 80 and lat <= -30 and lat >= -65 :
        return foret
    elif lng <= 40 and lng >= - 20 and lat <= 20  and lat >= -10 :
        return foret
    elif lng <= 140 and lng >= 100 and lat<= 40 and lat >= 30 :
        return foret
    elif lng <= 120 and lng >= 100 and lat<= 30 and lat >= 0 :
        return foret
    elif lng <= 160 and lng >= 100 and lat<= 0 and lat >= -10 :
        return foret
    elif lng <= 40 and lng >= 10 and lat<= -10 and lat >= -30 :
        return desert
    elif lng <= 60 and lng >= 0 and lat<= 40 and lat >= 20 :
        return desert
    elif lng <= 160 and lng >= 120 and lat<= -10 and lat >= -30 :
        return desert
    elif lng <= -80 and lng >= - 120 and lat<= 50 and lat >= 20 :
        return terre
    elif lng <= 140 and lng >= 0 and lat<= 60 and lat >= 30 :
        return terre
    elif lng <= 60 and lng >= 40 and lat<= 40 and lat >= 20 :
        return terre
    elif lng <= 100 and lng >= 40 and lat<= 40 and lat >= 20 :
        return terre
    else:
        return neige

def puiss_sol(lat, lng, h, j, puiss):
    '''Calcule la puissance totale reçue par la pacelle de sol après les différents rebonds liés à l'effet de serre, mais sans prendre en compte la réémission propre au corps noir qu'est la Terre. On considère ici que l'albedo de l'atmosphère      est constant, égal à 0.8. On somme toutes les réfléxions et on a mis ici la somme de la série, qui est une série géométrique de raison strictement inférieure à 1.'''
    p = (0.8*(1-albedo(lat,lng))*dpuiss (lat, lng, h, j, puiss))/(1-0.2*albedo(lat,lng))
    return p

def p_sol(lat, lng, h, j, puiss):
    '''Calcule la puissance reçue par la Terre après réémission des infrarouges liées au corps noir, en supposant que la Terre est un système thermodynamique à l'équilibre, elle re-reçoit donc une partie de ce qu'elle a ré-émis.'''
    Precue = puiss_sol(lat, lng, h, j, puiss)
    p = (Precue*(1.2-0.4*albedo(lat,lng)))/(1-0.2*albedo(lat,lng))
    return p

def temp(lat, lng, h, j,puiss):
    """calcul la temperature en un point donné (lat/long) en fonction de l'heure, le jour et la puissance"""
    puissrecu=p_sol(lat, lng, h, j,puiss) #calcul la puissance reçu apres le passage d'un rayon dans l'atmosphere
    alb=albedo(lat, lng) #prend l'abedo d'un point
    puisstot=puissrecu*(1-alb) #calcul la puissance avec l'albédo du sol
    temp = (puisstot/stef)**0.25 #calcul la temperature en fonction d'une puissance reçue
    print("temperature °C=",temp-273.15)
    return temp

heure = 8  # 8 heures
jour = 35  # 35ème jour de l'année
puiss = np.array([1340, 0, 0])  #vecteur de puissance


# Fonction pour créer une carte du monde avec Cartopy
def plot_world_map():
    """créer une carte du monde où l'on peut cliquer sur un point pour afficher la température"""
    fig = plt.figure(figsize=(10, 6))

    # Création de la carte du monde en utilisant la fonction Plate Carrée (planisphère)
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())

    # Ajout des éléments de la carte
    ax.coastlines()
    ax.gridlines(draw_labels=True)

    return fig, ax

# Créer la carte du monde
fig, ax = plot_world_map()

# Fonction pour obtenir les coordonnées des clics
def onclick(event):
    if event.inaxes == ax:

        lon, lat = ax.projection.transform_point(event.xdata, event.ydata, ccrs.PlateCarree())
        print(f'coordonnée: Longitude = {lon:.2f}, Latitude = {lat:.2f}')
        print(temp(convertir(lat),convertir(lon),heure,jour,puiss))


# Lier l'événement de clic à la fonction onclick
cid = fig.canvas.mpl_connect('button_press_event', onclick)
#afficher carte
plt.title('World Map')
plt.show()


