def update_temperature(T, Q_in, Q_out, C, dt):
    """
    Met à jour la température en fonction des entrées et sorties de chaleur.

    Arguments:
    T (float): Température actuelle (K)
    Q_in (float): Chaleur entrante (W/m^2)
    Q_out (float): Chaleur sortante (W/m^2)
    C (float): Capacité thermique (J/K/m^2)
    dt (float): Intervalle de temps (s)

    Retour:
    T_new (float): Nouvelle température (K)
    """
    dT = (Q_in - Q_out) * dt / C
    T_new = T + dT
    return T_new

# Paramètres du modèle
C = 5e6  # Capacité thermique approximative de la surface terrestre (J/K/m^2)
Q_in_day = 700  # Puissance solaire moyenne reçue pendant la journée (W/m^2)
Q_out_night = 100  # Perte de chaleur nocturne (W/m^2)
T_initial = 288  # Température initiale approximative de la Terre (15°C en Kelvin)
day_length = 12 * 3600  # Durée du jour en secondes
night_length = 12 * 3600  # Durée de la nuit en secondes
dt = 3600  # Pas de temps d'une heure

# Simulation sur 24 heures
T = T_initial
for _ in range(day_length // dt):
    T = update_temperature(T, Q_in_day, 0, C, dt)  # Journée, seulement Q_in
for _ in range(night_length // dt):
    T = update_temperature(T, 0, Q_out_night, C, dt)  # Nuit, seulement Q_out

print(f"La température moyenne de la surface après 24 heures est de {T:.2f} K.")
