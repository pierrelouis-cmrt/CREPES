def calculate_convective_heat_transfer(h, A, T1, T2):
    """
    Calcule le transfert de chaleur par convection entre deux mailles de température différente.

    Arguments:
    h (float): Coefficient de transfert de chaleur par convection (W/m^2K)
    A (float): Surface de contact (m^2)
    T1 (float): Température de la première maille (K ou °C)
    T2 (float): Température de la seconde maille (K ou °C)

    Retour:
    Q (float): Transfert de chaleur par convection (W)
    """
    Q = h * A * (T1 - T2)
    return Q

# Valeurs typiques
h = 10  # Coefficient de transfert de chaleur par convection pour l'air (W/m^2K)
A = 1.0  # Supposons une surface de contact d'1 m^2
T1 = float(input("Entrez la température de la première maille (en °C ou K): "))
T2 = float(input("Entrez la température de la seconde maille (en °C ou K): "))

# Calculer et afficher le transfert de chaleur par convection
heat_transfer = calculate_convective_heat_transfer(h, A, T1, T2)
print(f"Le transfert de chaleur par convection est de {heat_transfer:.2f} Watts.")
