# Importation des bibliothèques nécessaires
import numpy as np

# Constantes
g = 9.81  # gravité (m/s^2)
beta_air = 1/273  # Coefficient de dilatation thermique de l'air (1/K)
DeltaT = 10  # Différence de température (K)
L = 1  # Longueur caractéristique (m)

# Propriétés des matériaux
proprietes = {
    "Air": {"rho": 1.184, "mu": 18.5e-6, "beta": beta_air},
    "Roche": {"rho": 2700, "mu": 1e12, "beta": 1e-5},  # Valeurs approximatives
    "Noyau terrestre": {"rho": 11000, "mu": 1e11, "beta": 1e-5}  # Valeurs approximatives
}

# Calcul du nombre de Grashof
def calcul_grashof(rho, mu, beta):
    return (g * beta * DeltaT * L**3 * rho**2) / mu**2

# Résultats
nombres_grashof = {matiere: calcul_grashof(**proprietes[matiere]) for matiere in proprietes}

# Affichage des résultats
for matiere, grashof in nombres_grashof.items():
    print(f"Nombre de Grashof pour {matiere}: {grashof:.2e}")











